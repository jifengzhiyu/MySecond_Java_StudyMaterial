package com.itheima_02;

//import com.itheima_01.Student;

//import com.itheima_01.Student;
//Alt+Enter 快捷键导包

import com.itheima_01.Student;

public class StudentTest {
    public static void main(String[] args) {
        Student s = new Student();
        s.study();

        Student s2 = new Student();
        s2.study();


//        com.itheima_01.Student s = new com.itheima_01.Student();
//        s.study();
//
//        com.itheima_01.Student s2 = new com.itheima_01.Student();
//        s2.study();
    }
}
