package com.itheima;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot03ReadDataApplicationTests {

    @Test
    void contextLoads() {
    }

}
