package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot04ProfileApplication {

    public static void main(String[] args) {
        SpringApplication.run(Springboot04ProfileApplication.class, args);
    }

}
