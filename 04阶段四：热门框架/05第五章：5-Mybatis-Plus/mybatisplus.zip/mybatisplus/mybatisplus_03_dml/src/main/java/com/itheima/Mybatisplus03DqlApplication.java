package com.itheima;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mybatisplus03DqlApplication {

    public static void main(String[] args) {
        SpringApplication.run(Mybatisplus03DqlApplication.class, args);
    }

}
