package com.itheima.dao;

public interface BookDao {
    public void save();

    public void update();

    public void delete();

    public void select();
}
