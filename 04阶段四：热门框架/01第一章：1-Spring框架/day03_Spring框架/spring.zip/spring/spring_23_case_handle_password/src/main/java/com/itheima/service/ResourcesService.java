package com.itheima.service;

public interface ResourcesService {
    public boolean openURL(String url ,String password);

}
